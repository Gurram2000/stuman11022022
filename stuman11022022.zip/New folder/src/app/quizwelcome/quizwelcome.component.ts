import { viewClassName } from '@angular/compiler';
import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';

@Component({
  selector: 'app-quizwelcome',
  templateUrl: './quizwelcome.component.html',
  styleUrls: ['./quizwelcome.component.css']
})
export class QuizwelcomeComponent implements OnInit {

  @ViewChild('name') namekey!:ElementRef;
  constructor() { }

  ngOnInit(): void {
  }
  startQuiz(){
     localStorage.setItem("name",this.namekey.nativeElement.value);
     
  }

}
